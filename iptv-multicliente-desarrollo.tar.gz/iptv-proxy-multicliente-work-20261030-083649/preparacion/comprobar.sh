#!/bin/sh
set -eu

cd /opt/iptv-proxy-multicliente

echo "===== 1. RESOLVEDOR DEL PANEL ====="
test -f pkg/server/multiclient.go
echo "OK: multiclient.go"

echo
echo "===== 2. RUTAS XTREAM ====="
grep -n 'func (c *Config) routes' pkg/server/routes.go || true
grep -n 'func (c *Config) xtreamRoutes' pkg/server/routes.go || true

echo
echo "===== 3. AUTENTICACIÓN ====="
grep -n 'func (c *Config) authenticate' pkg/server/handlers.go || true
grep -n 'func (c *Config) appAuthenticate' pkg/server/handlers.go || true

echo
echo "===== 4. COMPILACIÓN DE PRUEBA ====="
docker build --pull=false -t iptv-proxy:multicliente-test .

echo
echo "===== 5. SERVICIOS EN PRODUCCIÓN ====="
docker ps --format 'table {{.Names}}\t{{.Status}}'

echo
echo "COMPROBACIÓN TERMINADA"
echo "No se ha modificado la producción."
