package server

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

// resolvedAccount contiene la respuesta del endpoint privado del panel.
type resolvedAccount struct {
	UserID           int64  `json:"user_id"`
	Username         string `json:"username"`
	Password         string `json:"password"`
	ProviderID       int64  `json:"provider_id"`
	ProviderBaseURL  string `json:"provider_base_url"`
	ProviderUsername string `json:"provider_username"`
	ProviderPassword string `json:"provider_password"`
}

type resolveRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

var panelHTTPClient = &http.Client{
	Timeout: 5 * time.Second,
	CheckRedirect: func(req *http.Request, via []*http.Request) error {
		return http.ErrUseLastResponse
	},
}

// resolvePanelAccount consulta el panel sin registrar ni exponer las
// credenciales enviadas o recibidas.
func resolvePanelAccount(ctx context.Context, username, password string) (*resolvedAccount, error) {
	endpoint := strings.TrimSpace(os.Getenv("PANEL_API_URL"))
	tokenFile := strings.TrimSpace(os.Getenv("PANEL_API_TOKEN_FILE"))

	if endpoint == "" || tokenFile == "" {
		return nil, errors.New("integración con el panel no configurada")
	}
	if username == "" || password == "" {
		return nil, errors.New("credenciales incompletas")
	}

	tokenBytes, err := os.ReadFile(tokenFile)
	if err != nil {
		return nil, errors.New("no se pudo leer la credencial interna del panel")
	}
	token := strings.TrimSpace(string(tokenBytes))
	if token == "" {
		return nil, errors.New("credencial interna del panel vacía")
	}

	body, err := json.Marshal(resolveRequest{
		Username: username,
		Password: password,
	})
	if err != nil {
		return nil, errors.New("no se pudo preparar la consulta al panel")
	}

	req, err := http.NewRequestWithContext(
		ctx, http.MethodPost, endpoint, bytes.NewReader(body),
	)
	if err != nil {
		return nil, errors.New("no se pudo preparar la petición al panel")
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)

	resp, err := panelHTTPClient.Do(req)
	if err != nil {
		return nil, errors.New("no se pudo contactar con el panel")
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 4096))
		return nil, fmt.Errorf("el panel rechazó la resolución (HTTP %d)", resp.StatusCode)
	}

	var account resolvedAccount
	decoder := json.NewDecoder(io.LimitReader(resp.Body, 64*1024))
	if err := decoder.Decode(&account); err != nil {
		return nil, errors.New("respuesta del panel no válida")
	}

	if account.UserID <= 0 ||
		account.Username == "" ||
		account.Password == "" ||
		account.ProviderID <= 0 ||
		account.ProviderBaseURL == "" ||
		account.ProviderUsername == "" ||
		account.ProviderPassword == "" {
		return nil, errors.New("el panel devolvió una asignación incompleta")
	}

	return &account, nil
}
